# David OCONTE

This is my CV.

<img src="./app/src/main/res/drawable/mycv.png?Raw=true" width="30%" height="30%">

## COMPETENCES

  - ### Logiciels :

    - Android Studio
    - HTML5, CSS3
    - PHP, SQl, JAVASCRIPT, LAMP
    - GIMP,  Drupal 7 et 8
    - SIG : Cart@jour, Gérémi, mapinfo, topspanc, Qgis et saphir, porteau pour l’eau potable
    - Autocad et la suite Microsoft

  - ### Administratives :

    - Mise en place du service, de la communication au prés des usagers
    - Animation des commissions avec les élus et réunions publiques
    - Rédaction des rapports, et collecte des données sur logiciel
    - Réalisation du budget prévisionnel et de la facturation émission des titres
    - Accompagnement pour l'obtention de subventions de l'agence de l'eau (ANC, AC et EP).
    - Suivi de chantier ANC, système autonome plus de 20 EH, AC et AEP, entretien de rivières.
    - Travaux sur un lagunage.
    
  - ### Techniques :

    - Intervention et suivi sur des micro stations de plus de 20 EH et cas spéciaux (ex: laiterie), mesure et réglage du chlore en station et réservoir.
    - Suivi et contrôle de chantiers.
    - Chiffrage de travaux (branchement neuf, nouvelle antenne de distribution, travaux de mise aux normes sur réservoir, ...)
    - Mise en route et relève de compteur (mise en place de la télé relève type sofrel)
    - Participation au groupe de travail SPANC Drôme et Ardeche et le conseil général.
    - Anglais parlé et écrit (contrôles SPANC en Anglais), Italien scolaire

## EXPERIENCES PROFESSIONNELLES

  - Octobre - Décembre 2016: Stage de perfectionnement en Réseau Urbain et Management.
  - Mai 2014 - 31 octobre 2015 : Mission de mise en place et gestion du service ANC pour une collectivité.
  - 2012 - Mai 2013 : SAUR Chargé de missions auprès du Chef de secteur
  - 2010 – 2012 : BTSA GEMEAU option GSEA en alternance à la communauté des communes du Pays de Marsanne, création et gestion du service SPANC.

## ETUDES ET DIPLOMES

  - 2019 -aujourd'hui Etudiant OpenClassRooms parcours DA Android
  - 2010 – 2012 : BTSA Gestion et Maîtrise de l’eau option GSEA CFA Nîmes-Rodihlan en alternance et réalisation d'un mémoire technique.
  - 2009 – 2010 : Licence de Biologie à Toulon
  - 2009 : Bac S option biologie écologie

## CENTRES D'INTERET

  - Sport : équitation (galop 7), polo en compétition (champion de France 2016), jeux vidéos sur
  - multi supports, VTT et la randonnée
